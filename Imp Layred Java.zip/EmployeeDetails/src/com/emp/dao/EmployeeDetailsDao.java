package com.emp.dao;

import com.emp.bean.EmployeeDetailsBean;
import com.emp.exception.EmployeeDetailsException;

public interface EmployeeDetailsDao {

	public int addEmployee(EmployeeDetailsBean bean) throws EmployeeDetailsException;
	public String viewById(int id) throws EmployeeDetailsException;
}
