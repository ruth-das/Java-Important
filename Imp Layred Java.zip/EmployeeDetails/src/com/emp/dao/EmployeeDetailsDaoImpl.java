package com.emp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.emp.bean.EmployeeDetailsBean;
import com.emp.exception.EmployeeDetailsException;
import com.emp.util.DBConnection;

public class EmployeeDetailsDaoImpl implements EmployeeDetailsDao {

	Logger logger = Logger.getRootLogger();

	public EmployeeDetailsDaoImpl() {
		super();
		PropertyConfigurator.configure("resource/log4j.properties");
	}

	public int generateEmployeeID() {
		int id = 0;
		Connection con = null;
		String qry = "select employeeid_sequence.nextval from dual";
		try {
			con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rst = stmt.executeQuery(qry);
			rst.next();
			id = rst.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.getMessage());
		}
		return id;
	}

	@Override
	public int addEmployee(EmployeeDetailsBean bean)
			throws EmployeeDetailsException {
		Connection con = null;
		String cmd = "insert into employee_table(emp_id,emp_firstname,"
				+ "emp_lastname,emp_contactno,emp_doj,"
				+ "emp_email) values(?,?,?,?,SYSDATE,?)";
		int id = 0;
		PreparedStatement pstmt;
		try {
			con = DBConnection.getConnection();
			id = generateEmployeeID();
			pstmt = con.prepareStatement(cmd);
			pstmt.setInt(1, id);
			pstmt.setString(2, bean.getEmpFirstName());
			pstmt.setString(3, bean.getEmpLastName());
			pstmt.setLong(4, bean.getEmpContactNo());
			pstmt.setString(5, bean.getEmpEmail());
			pstmt.executeUpdate();

		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new EmployeeDetailsException("Unable to insert");
		}

		return id;
	}

	public String viewById(int id) throws EmployeeDetailsException {
		Connection con = null;
		EmployeeDetailsBean bean = new EmployeeDetailsBean();
		String cmd = "select emp_id,emp_firstname,emp_lastname, "
				+ "emp_contactno,emp_doj,emp_email from "
				+ "employee_table where emp_id=" + id;

		try {

			con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rst = stmt.executeQuery(cmd);
			System.out.println("Employee Details are: ");
			rst.next();
			bean.setEmpId(rst.getInt(1));
			bean.setEmpFirstName(rst.getString(2));
			bean.setEmpLastName(rst.getString(3));
			bean.setEmpContactNo(rst.getLong(4));
			bean.setDoj(rst.getDate(5));
			bean.setEmpEmail(rst.getString(6));
			logger.info("View Success");
		} catch (SQLException e) {
			logger.error(e.getMessage());
			System.out.println(e);
		}
		return (bean.getEmpId() + " " + bean.getEmpFirstName() + " "
				+ bean.getEmpLastName() + " " + bean.getEmpContactNo() + " "
				+ bean.getDoj() + " " + bean.getEmpEmail());
	}
}
