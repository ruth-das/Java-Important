package com.emp.exception;

public class EmployeeDetailsException extends Exception{
	
	public EmployeeDetailsException(String msg)
	{
		super(msg);
	}

}
