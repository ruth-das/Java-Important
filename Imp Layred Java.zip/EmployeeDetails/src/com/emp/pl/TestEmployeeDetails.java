package com.emp.pl;

import java.util.Scanner;





import org.apache.log4j.Logger;

import com.emp.bean.EmployeeDetailsBean;
import com.emp.exception.EmployeeDetailsException;
import com.emp.service.EmployeeDetailsService;
import com.emp.service.EmployeeDetailsServiceImpl;

public class TestEmployeeDetails {
	
	static Logger logger=Logger.getRootLogger();
	static EmployeeDetailsServiceImpl employeeServiceImpl = null;
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		EmployeeDetailsBean bean = new EmployeeDetailsBean();
		EmployeeDetailsService service=new EmployeeDetailsServiceImpl();
		
		System.out.println("Select Operations:\n1.ADD Employee"
				+ "\n2.VIEW Employee\n3.EXIT");
		int choice = sc.nextInt();
		switch(choice) {
		case 1:
			System.out.println("Enter Employee First Name: ");
			String fname=sc.next();
			System.out.println("Enter Employee Last Name: ");
			String lname=sc.next();
			System.out.println("Enter Employee Contact Number: ");
			long cno=sc.nextLong();
			System.out.println("Enter Employee Email: ");
			String mail=sc.next();
		
			bean.setEmpFirstName(fname);
			bean.setEmpLastName(lname);
			bean.setEmpContactNo(cno);
			bean.setEmpEmail(mail);
			
			employeeServiceImpl = new EmployeeDetailsServiceImpl();
			try {
				if(employeeServiceImpl.validateEmployeeDetails(bean))
				{
					System.out.println("Wrong Details");
					
				}
			} catch (EmployeeDetailsException e1) {	
				e1.printStackTrace();
				System.err.println("Invalid Data");
				logger.error("Invalid Data",e1);
				System.exit(0);
			}
			
			try {
				int id=service.addEmployee(bean);
				System.out.println("Employee Added Successfully");
				System.out.println("Employee ID: "+id);
				logger.info("Employee Added Successfully");
			} catch (EmployeeDetailsException e) {
				System.out.println(e);
				logger.info("Could not add employee", e);
			}
			break;
		case 2:
			try{
				System.out.println("Enter the Employee's ID:");
				int id=sc.nextInt();
				System.out.println(service.viewById(id));
			}catch(EmployeeDetailsException e){
				e.printStackTrace();
				logger.info("Could not view employee details", e);
			}
			break;
		case 3:
			System.out.println("Application Exited");
			logger.info("Exited");
			System.exit(0);
			break;
			default:
				System.out.println("Enter valid choice[1-3]");
				logger.info("Invalid choice");
				break;
		}
		sc.close();
	}

}
