package com.emp.service;

import com.emp.bean.EmployeeDetailsBean;
import com.emp.exception.EmployeeDetailsException;


public interface EmployeeDetailsService {

	int addEmployee(EmployeeDetailsBean bean)throws EmployeeDetailsException;
	String viewById(int id) throws EmployeeDetailsException;
}
