package com.emp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.emp.bean.EmployeeDetailsBean;
import com.emp.dao.EmployeeDetailsDao;
import com.emp.dao.EmployeeDetailsDaoImpl;
import com.emp.exception.EmployeeDetailsException;

public class EmployeeDetailsServiceImpl implements EmployeeDetailsService {

	EmployeeDetailsDao employeedao = new EmployeeDetailsDaoImpl();

	@Override
	public int addEmployee(EmployeeDetailsBean bean)
			throws EmployeeDetailsException {
		int id = employeedao.addEmployee(bean);
		return id;
	}

	public String viewById(int id) throws EmployeeDetailsException {
		String bean = employeedao.viewById(id);
		return bean;
	}

	public boolean validateEmployeeDetails(EmployeeDetailsBean bean)
			throws EmployeeDetailsException {
		boolean validate = true;
		List<String> validationErrors = new ArrayList<String>();

		if (!(isValidFirstName(bean.getEmpFirstName()))) {
			validationErrors
					.add("\n First Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}

		if (!(isValidLastName(bean.getEmpLastName()))) {
			validationErrors
					.add("\n Last Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}

		if (!(isValidNumber(bean.getEmpContactNo()))) {
			validationErrors.add("\n Phone Number Should be in 10 digit \n");
		}

		if (!(isValidEmail(bean.getEmpEmail()))) {
			validationErrors.add("\n Give valid email id \n");
		}

		if (!validationErrors.isEmpty()) {
			throw new EmployeeDetailsException(validationErrors + "");

		} else {
			validate = false;
		}
		return validate;
	}

	public boolean isValidFirstName(String empFirstName) {
		Pattern fnamePattern = Pattern.compile("[A-Z][a-z]{1,14}");
		Matcher fnameMatcher = fnamePattern.matcher(empFirstName);
		return fnameMatcher.matches();
	}

	public boolean isValidLastName(String empLastName) {
		Pattern lnamePattern = Pattern.compile("[A-Z][a-z]{1,14}");
		Matcher lnameMatcher = lnamePattern.matcher(empLastName);
		return lnameMatcher.matches();
	}

	public boolean isValidNumber(Long empContactNumber) {
		Pattern phonePattern = Pattern.compile("[1-9]{1}[0-9]{9}$");
		Matcher phoneMatcher = phonePattern.matcher(String
				.valueOf(empContactNumber));
		return phoneMatcher.matches();
	}

	public boolean isValidEmail(String empEmail) {
		Pattern mailPattern = Pattern.compile("[a-z]{1,5}@[a-z]{1,5}.com");
		Matcher mailMatcher = mailPattern.matcher(empEmail);
		return mailMatcher.matches();
	}
}
