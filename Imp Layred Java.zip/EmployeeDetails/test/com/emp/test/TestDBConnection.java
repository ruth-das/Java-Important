package com.emp.test;

import static org.junit.Assert.*;

import java.sql.Connection;

import org.junit.Test;

import com.emp.exception.EmployeeDetailsException;
import com.emp.util.DBConnection;



public class TestDBConnection {

	@Test
	public void testConnection() throws EmployeeDetailsException{
		Connection con=DBConnection.getConnection();
		assertNotNull(con);
	}
	@Test(expected=EmployeeDetailsException.class)
	public void testConnectionFail() throws EmployeeDetailsException{
		Connection con=DBConnection.getConnection();
	}
}
