package com.emp.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.emp.bean.EmployeeDetailsBean;
import com.emp.dao.EmployeeDetailsDaoImpl;
import com.emp.exception.EmployeeDetailsException;

public class TestDaoImpl {

	static EmployeeDetailsDaoImpl employeeDao;
	static EmployeeDetailsBean bean;

	@BeforeClass
	public static void beforeClass() {
		employeeDao = new EmployeeDetailsDaoImpl();
		bean = new EmployeeDetailsBean();
	}

	@Test
	public void testAddEmployee() throws EmployeeDetailsException {
		bean.setEmpFirstName("Ruth");
		bean.setEmpLastName("Das");
		bean.setEmpContactNo(8892528395L);
		bean.setEmpEmail("ruth@gmail.com");
		int id = employeeDao.addEmployee(bean);
		assertTrue(id > 0);
	}
}
